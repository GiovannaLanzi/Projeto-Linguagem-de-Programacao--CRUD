// Importação das bibliotecas necessárias
const express = require("express");
const cors = require("cors");
const mysql = require('mysql');

// Configuração da conexão
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'projeto',
    port: 3306
});

// Conectar ao banco de dados
connection.connect(error => {
    if (error) {
        console.error('Erro ao conectar:', error.stack);
        return;
    }
    console.log('Conectado com o ID ' + connection.threadId);
});

// Criação do servidor Express
const app = express();
const port = 3003;

// Configurações do Express
app.use(express.json());
app.use(cors());

// Rota para listar todas as cores
app.get("/cores", (req, res) => {
    const querySelect = 'SELECT * FROM cores';
    connection.query(querySelect, (error, results) => {
        if (error) {
            console.error('Erro no SELECT:', error);
            return res.status(500).json({ error: 'Erro ao listar as cores' });
        }
        return res.json(results);
    });
});

// Rota para listar uma cor específica
app.get("/cores/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const querySelectID = `SELECT * FROM cores WHERE idCor = ${id}`;
    connection.query(querySelectID, [id], (error, results) => {
        if (error) {
            console.error('Erro no SELECT da cor:', error);
            return res.status(500).json({ error: 'Erro ao buscar cor' });
        }
        return res.json(results[0]);
    });
});

// Rota para inserir uma cor
app.post("/cores", (req, res) => {
    const newCor = req.body;
    const valoresInserir = [newCor.idCor, newCor.nomeCor];
    const queryInsert = 'INSERT INTO cores (idCor, nomeCor) VALUES (?, ?)';

    connection.query(queryInsert, valoresInserir, (error, results) => {
        if (error) {
            console.error('Erro no INSERT:', error);
            return res.status(500).json({ error: 'Erro ao inserir a cor' });
        }
        return res.status(201).json(newCor);
    });
});

// Rota para alterar uma cor
app.put("/cores/:id", (req, res) => {
    console.log("PUT /cores/:id");

    const originalId = parseInt(req.params.id);
    const updatedCor = req.body;

    const fieldsToUpdate = [];
    const valuesUpdate = [];

    if (updatedCor.idCor !== undefined && updatedCor.idCor !== originalId) {
        fieldsToUpdate.push("idCor = ?");
        valuesUpdate.push(updatedCor.idCor);
    }

    if (updatedCor.nomeCor) {
        fieldsToUpdate.push("nomeCor = ?");
        valuesUpdate.push(updatedCor.nomeCor);
    }

    if (fieldsToUpdate.length === 0) {
        return res.status(400).json({ error: 'Nenhum campo para atualizar fornecido.' });
    }

    const queryUpdate = `UPDATE cores SET ${fieldsToUpdate.join(', ')} WHERE idCor = ?`;
    valuesUpdate.push(originalId);

    connection.query(queryUpdate, valuesUpdate, (error, results, fields) => {
        if (error) {
            console.error('Erro no UPDATE de cor específica:', error);
            return res.status(500).json({ error: 'Erro ao atualizar cor' });
        }

        console.log('UPDATE de cor realizado com sucesso!');

        const corAtualizada = {
            idCor: updatedCor.idCor || originalId,
            nomeCor: updatedCor.nomeCor || undefined,
        };

        return res.status(200).json(corAtualizada);
    });
});


// Rota para deletar uma cor
app.delete("/cores/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const queryDelete = `DELETE FROM cores WHERE idCor = ?`;

    connection.query(queryDelete, [id], (error, results) => {
        if (error) {
            console.error('Erro no DELETE:', error);
            return res.status(500).json({ error: 'Erro ao deletar cor' });
        }
        return res.json({ message: 'Cor deletada com sucesso' });
    });
});

// Inicia o servidor
app.listen(port, () => {
    console.log(`Servidor iniciado na porta ${port}`);
});