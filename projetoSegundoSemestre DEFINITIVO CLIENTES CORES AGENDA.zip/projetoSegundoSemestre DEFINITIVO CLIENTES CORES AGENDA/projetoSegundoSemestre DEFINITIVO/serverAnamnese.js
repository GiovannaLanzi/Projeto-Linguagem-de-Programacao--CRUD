// Importação das bibliotecas necessárias
const express = require("express");
const cors = require("cors");
const mysql = require('mysql');

// Configuração da conexão
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'projeto',
    port: 3306
});

// Conectar ao banco de dados
connection.connect(error => {
    if (error) {
        console.error('Erro ao conectar:', error.stack);
        return;
    }
    console.log('Conectado com o ID ' + connection.threadId);
});

// Criação do servidor Express
const app = express();
const port = 3005;

// Configurações do Express
app.use(express.json());
app.use(cors());

// Rota para listar todas as anamneses
app.get("/anamnese", (req, res) => {
    const querySelect = 'SELECT * FROM Anamnese';
    connection.query(querySelect, (error, results) => {
        if (error) {
            console.error('Erro no SELECT:', error);
            return res.status(500).json({ error: 'Erro ao listar as anamneses' });
        }
        return res.json(results);
    });
});

// Rota para listar uma anamnese específica
app.get("/anamnese/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const querySelectID = `SELECT * FROM Anamnese WHERE idAnamnese = ${id}`;
    connection.query(querySelectID, [id], (error, results) => {
        if (error) {
            console.error('Erro no SELECT da anamnese:', error);
            return res.status(500).json({ error: 'Erro ao buscar anamnese' });
        }
        return res.json(results[0]);
    });
});

// Rota para inserir uma anamnese
app.post("/anamnese", (req, res) => {
    const newAnamnese = req.body;

    // Pegando os valores do corpo da requisição
    const valoresInserir = [newAnamnese.idAnamnese, newAnamnese.alergias, newAnamnese.historicoMedico];

    const queryInsert = 'INSERT INTO Anamnese (idAnamnese, alergias, historicoMedico) VALUES (?, ?, ?)';

    connection.query(queryInsert, valoresInserir, (error, results) => {
        if (error) {
            console.error('Erro no INSERT:', error);
            return res.status(500).json({ error: 'Erro ao inserir a anamnese' });
        }

        // Retorna a anamnese com o idAnamnese fornecido
        return res.status(201).json(newAnamnese);
    });
});

// Rota para excluir uma anamnese
app.delete("/anamnese/:id", (req, res) => {
    const id = parseInt(req.params.id);

    const queryDelete = 'DELETE FROM Anamnese WHERE idAnamnese = ?';

    connection.query(queryDelete, [id], (error, results) => {
        if (error) {
            console.error('Erro no DELETE:', error);
            return res.status(500).json({ error: 'Erro ao excluir a anamnese' });
        }

        return res.status(200).json({ message: 'Anamnese excluída com sucesso' });
    });
});

// Rota para atualizar uma anamnese (incluindo o ID)
app.put("/anamnese/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const updatedAnamnese = req.body;

    const newId = updatedAnamnese.idAnamnese;
    const checkIdQuery = 'SELECT * FROM Anamnese WHERE idAnamnese = ?';

    connection.query(checkIdQuery, [newId], (error, results) => {
        if (error) {
            return res.status(500).json({ message: "Erro ao verificar ID no banco de dados", error });
        }

        if (results.length > 0 && newId !== id) {
            return res.status(400).json({ message: "ID Anamnese já está em uso" });
        }

        const updateQuery = 'UPDATE Anamnese SET idAnamnese = ?, alergias = ?, historicoMedico = ? WHERE idAnamnese = ?';
        connection.query(updateQuery, [updatedAnamnese.idAnamnese, updatedAnamnese.alergias, updatedAnamnese.historicoMedico, id], (error, results) => {
            if (error) {
                return res.status(500).json({ message: "Erro ao atualizar ficha de anamnese", error });
            }

            res.status(200).json(updatedAnamnese);
        });
    });
});


// Rota para excluir uma anamnese
app.delete("/anamnese/:id", (req, res) => {
    const id = parseInt(req.params.id);

    const queryDelete = 'DELETE FROM Anamnese WHERE idAnamnese = ?';
    connection.query(queryDelete, [id], (error, results) => {
        if (error) {
            console.error('Erro no DELETE:', error);
            return res.status(500).json({ error: 'Erro ao excluir a anamnese' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ error: 'Anamnese não encontrada' });
        }
        return res.status(200).json({ message: 'Anamnese excluída com sucesso' });
    });
});

// Inicia o servidor
app.listen(port, () => {
    console.log(`Servidor iniciado na porta ${port}`);
});