-- BANCO MYSQL --
CREATE DATABASE projeto;
USE projeto;

CREATE TABLE cliente (
    id INT PRIMARY KEY,
    nome VARCHAR(100)
);

CREATE TABLE cores (
    idCor INT PRIMARY KEY,
    nomeCor VARCHAR(100)
);

CREATE TABLE agendamento (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100),
    dataHora DATETIME
);
