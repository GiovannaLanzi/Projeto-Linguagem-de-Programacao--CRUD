// Importação das bibliotecas necessárias
const express = require("express");
const cors = require("cors");
const mysql = require('mysql');

// Configuração da conexão
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'projeto',
    port: 3306
});

// Conectar ao banco de dados
connection.connect(error => {
    if (error) {
        console.error('Erro ao conectar:', error.stack);
        return;
    }
    console.log('Conectado com o ID ' + connection.threadId);
});

// Criação do servidor Express
const app = express();

// Definição da porta do servidor
const port = 3002;

// Configurações do Express
app.use(express.json());

// Configuração do CORS
app.use(cors());

// Rota para listar todos os clientes
app.get("/clientes", (req, res) => {
    console.log("GET /clientes");

    const querySelect = 'SELECT * FROM cliente';
    connection.query(querySelect, (error, results, fields) => {
        if (error) {
            console.error('Erro no SELECT dos clientes:', error);
            return;
        }
        console.log('Select realizado com sucesso!');
        return res.json(results);
    });
});

// Rota para listar um cliente específico
app.get("/clientes/:id", (req, res) => {
    console.log("GET /clientes/:id");

    const id = parseInt(req.params.id);

    const querySelectID = `SELECT * FROM cliente WHERE id = ${id}`;
    connection.query(querySelectID, (error, results, fields) => {
        if (error) {
            console.error('Erro no SELECT do cliente específico:', error);
            return;
        }
        console.log('Select do cliente específico realizado com sucesso!');
        return res.json(results);
    });
});

// Rota para INSERIR clientes
app.post("/clientes", (req, res) => {
    console.log("POST /clientes");

    const newCliente = req.body;
    const valoresInserir = [newCliente.id, newCliente.nome];

    const queryInsert = 'INSERT INTO cliente (id, nome) VALUES (?, ?)';
    
    connection.query(queryInsert, valoresInserir, (error, results, fields) => {
        if (error) {
            console.error('Erro no INSERT dos clientes:', error);
            return res.status(500).json({ error: 'Erro ao inserir o cliente' });
        }
        
        console.log('INSERT realizado com sucesso!');

        const clienteInserido = {
            id: newCliente.id,
            nome: newCliente.nome
        };

        return res.status(201).json(clienteInserido);
    });
});

// Rota para ALTERAR um cliente específico
app.put("/clientes/:id", (req, res) => {
    console.log("PUT /clientes/:id");

    const id = parseInt(req.params.id);
    const updatedCliente = req.body;

    const fieldsToUpdate = [];
    const valuesUpdate = [];

    if (updatedCliente.id !== undefined) {
        fieldsToUpdate.push("id = ?");
        valuesUpdate.push(updatedCliente.id);
    }
    if (updatedCliente.nome) {
        fieldsToUpdate.push("nome = ?");
        valuesUpdate.push(updatedCliente.nome);
    }

    if (fieldsToUpdate.length === 0) {
        return res.status(400).json({ error: 'Nenhum campo para atualizar fornecido.' });
    }

    const queryUpdate = `UPDATE cliente SET ${fieldsToUpdate.join(', ')} WHERE id = ?`;
    valuesUpdate.push(id);

    connection.query(queryUpdate, valuesUpdate, (error, results, fields) => {
        if (error) {
            console.error('Erro no UPDATE do cliente específico:', error);
            return res.status(500).json({ error: 'Erro ao atualizar cliente' });
        }

        console.log('UPDATE do cliente realizado com sucesso!');

        const clienteAtualizado = {
            id: updatedCliente.id || id,
            nome: updatedCliente.nome || undefined,
        };

        return res.status(200).json(clienteAtualizado);
    });
});

// Rota para DELETAR um cliente específico
app.delete("/clientes/:id", (req, res) => {
    console.log("DELETE /clientes/:id");

    const id = parseInt(req.params.id);

    const queryDelete = `DELETE FROM cliente WHERE id = ${id}`;
    connection.query(queryDelete, (error, results, fields) => {
        if (error) {
            console.error('Erro no DELETE do cliente específico:', error);
            return res.status(500).json({ error: 'Erro ao deletar cliente' });
        }
        console.log('DELETE do cliente realizado com sucesso!');
        return res.json(results);
    });
});

// Inicia o servidor
app.listen(port, () => {
    console.log(`Servidor iniciado na porta ${port}`);
});