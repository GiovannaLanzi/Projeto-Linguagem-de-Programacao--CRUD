// Importação das bibliotecas necessárias
const express = require("express");
const cors = require("cors");
const mysql = require('mysql');

// Configuração da conexão
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'projeto',
    port: 3306
});

// Conectar ao banco de dados
connection.connect(error => {
    if (error) {
        console.error('Erro ao conectar:', error.stack);
        return;
    }
    console.log('Conectado com o ID ' + connection.threadId);
});

// Criação do servidor Express
const app = express();

// Definição da porta do servidor
const port = 3004;

// Configurações do Express
app.use(express.json());

// Configuração do CORS
app.use(cors());

// Rota para listar todos os agendamento
app.get("/agendamento", (req, res) => {
    console.log("GET /agendamento");

    const querySelect = 'SELECT * FROM agendamento';
    connection.query(querySelect, (error, results, fields) => {
        if (error) {
            console.error('Erro no SELECT dos agendamento:', error);
            return;
        }
        console.log('Select realizado com sucesso!');
        return res.json(results);
    });
});

// Rota para listar um agendamento específico
app.get("/agendamento/:id", (req, res) => {
    console.log("GET /agendamento/:id");

    const id = parseInt(req.params.id);

    const querySelectID = `SELECT * FROM agendamento WHERE id = ${id}`;
    connection.query(querySelectID, (error, results, fields) => {
        if (error) {
            console.error('Erro no SELECT do agendamento específico:', error);
            return;
        }
        console.log('Select do agendamento específico realizado com sucesso!');
        return res.json(results);
    });
});

// Rota para INSERIR agendamento
app.post("/agendamento", (req, res) => {
    console.log("POST /agendamento");

    const newAgendamento = req.body;
    const valoresInserir = [newAgendamento.id, newAgendamento.nome];

    const queryInsert = 'INSERT INTO agendamento (id, nome) VALUES (?, ?)';
    
    connection.query(queryInsert, valoresInserir, (error, results, fields) => {
        if (error) {
            console.error('Erro no INSERT dos agendamento:', error);
            return res.status(500).json({ error: 'Erro ao inserir o agendamento' });
        }
        
        console.log('INSERT realizado com sucesso!');

        const agendamentoInserido = {
            id: newAgendamento.id,
            nome: newAgendamento.nome
        };

        return res.status(201).json(agendamentoInserido);
    });
});

// Rota para ALTERAR um agendamento específico
app.put("/agendamento/:id", (req, res) => {
    console.log("PUT /agendamento/:id");

    const id = parseInt(req.params.id);
    const updatedAgendamento = req.body;

    const fieldsToUpdate = [];
    const valuesUpdate = [];

    if (updatedAgendamento.id !== undefined) {
        fieldsToUpdate.push("id = ?");
        valuesUpdate.push(updatedAgendamento.id);
    }
    if (updatedAgendamento.nome) {
        fieldsToUpdate.push("nome = ?");
        valuesUpdate.push(updatedAgendamento.nome);
    }

    if (fieldsToUpdate.length === 0) {
        return res.status(400).json({ error: 'Nenhum campo para atualizar fornecido.' });
    }

    const queryUpdate = `UPDATE agendamento SET ${fieldsToUpdate.join(', ')} WHERE id = ?`;
    valuesUpdate.push(id);

    connection.query(queryUpdate, valuesUpdate, (error, results, fields) => {
        if (error) {
            console.error('Erro no UPDATE do agendamento específico:', error);
            return res.status(500).json({ error: 'Erro ao atualizar agendamento' });
        }

        console.log('UPDATE do agendamento realizado com sucesso!');

        const agendamentoAtualizado = {
            id: updatedAgendamento.id || id,
            nome: updatedAgendamento.nome || undefined,
        };

        return res.status(200).json(agendamentoAtualizado);
    });
});

// Rota para DELETAR um agendamento específico
app.delete("/agendamento/:id", (req, res) => {
    console.log("DELETE /agendamentos/:id");

    const id = parseInt(req.params.id);

    const queryDelete = `DELETE FROM agendamento WHERE id = ${id}`;
    connection.query(queryDelete, (error, results, fields) => {
        if (error) {
            console.error('Erro no DELETE do agendamento específico:', error);
            return res.status(500).json({ error: 'Erro ao deletar agendamento' });
        }
        console.log('DELETE do agendamento realizado com sucesso!');
        return res.json(results);
    });
});

// Inicia o servidor
app.listen(port, () => {
    console.log(`Servidor iniciado na porta ${port}`);
});